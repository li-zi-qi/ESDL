function [D,X] = Learn_D_X(train_data,Mirror_data,Dinit,alpha,beta,gamma,diedai,Q)

[L_size,L_size1]=size(Dinit'*Dinit);
D=Dinit;

for j=1:diedai
    % verify dictionary normalization
    % sparse coding
    
    X1=(D'*D+alpha*(D'*D)+beta*eye(L_size1)+gamma*eye(L_size1));
    [numx1,x1]=size(find(isnan(X1)));
    [numx2,x]= size(find(isinf(X1)));
    if(numx1>0 )||(numx2>0)
        X1=eye(L_size1);
    end
    X2=pinv(X1);
    X3=(D'*train_data+alpha*D'*Mirror_data+gamma*Q);
    X=X2*X3;
    
    D1=(X*X'+alpha*(X*X'));
    [numd1,ad1]=size(find(isnan(D1)));
    [numd2,ad2]= size(find(isinf(D1)));
    if(numd1>0 )||(numd2>0)
        [ds,ds]=size(X*X');
        D1=eye(ds);
    end
    D3=pinv(D1);
    D4=train_data*X'+alpha*Mirror_data*X';
    D=D4*D3;
    
end

D=normcols(D);
X=normcols(X);