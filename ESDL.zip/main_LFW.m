clear
clc
close all

addpath(genpath('ksvdbox13'));  % add K-SVD box
addpath(genpath('ompbox10')); % add sparse coding algorithem OMP

% load data
load('LFW_1251.mat');
load('Tr_ind_lfw.mat')

gnd = gnd';
dictsize = 430; % the number of atoms

sparsitythres = 30; % sparsity prior
iterations = 10;  %iteration number
alpha = 1e-4;  %parameter
beta = 1e-3;% parameter
gamma = 1e-3;% parameter
rows = 32;
cols = 32;

ClassID = unique(gnd);
ClassNum = length(ClassID);

experiments = size(Tr_ind,1);
recog_rate = zeros(1,experiments);

% repeat the experiment ten times
for jjj=1:experiments
    train_ind=Tr_ind(jjj,:);
    
    train_ind=logical(train_ind);
    test_ind=~train_ind;
    
    train_data=gray_lsw(:,train_ind);
    train_label=gnd(:,train_ind);
    
    test_data=gray_lsw(:,test_ind);
    test_label=gnd(:,test_ind);
    
    H_train=full(ind2vec(train_label,ClassNum));
    H_test=full(ind2vec(test_label,ClassNum));
    
    train_data1=train_data;
    train_data2=zeros(size(train_data1));
    for i=1:size(train_data1,2)
        a=train_data1(:,i);
        A=reshape(a,rows,cols);
        %     imshow(uint8(A));
        B=fliplr(A);
        b=B(:);
        train_data2(:,i)=b;
    end
    
    % initialize the dictionary and Q
    [Dinit,Q]=initializationDictionary(train_data,H_train,dictsize,iterations,sparsitythres);
    
    % calculate the dictioanry and coding coefficient
    [D,X] = Learn_D_X(train_data1,train_data2,Dinit,alpha,beta,gamma,iterations,Q);
    
    % calculate the classification parameter W
    lambda = 10;
    W= (X*X'+lambda*eye(size(X*X')))\X*H_train';
    W = W';
    W=normcols(W);
    
    % classification
    [prediction,accuracy] = classification(D, W, test_data, H_test,sparsitythres);
    fprintf('\n %.03f,',accuracy);
    recog_rate(jjj)=accuracy;
    
end %jjj

Ravg = mean(recog_rate);                  % average recognition rate
Rstd = std(recog_rate);                   % standard deviation of the recognition rate
fprintf('\n===================================');
fprintf('\nAverage classification accuracy: %f\n', Ravg);
fprintf('Standard deviation: %f\n', Rstd);
fprintf('=====================================');



